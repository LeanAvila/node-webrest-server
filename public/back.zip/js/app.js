
console.log('hola mundo');